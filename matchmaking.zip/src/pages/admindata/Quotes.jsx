import React, { useEffect, useState } from 'react';
import { getAllQuotes, setQuoteStatus } from '../../services/adminService';
import { t } from '../../lib/i18n';

const Quotes = () => {
  const [quotes, setQuotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    getAllQuotes().then(setQuotes).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const filtered = quotes.filter(q => filter === 'all' ? true : q.status === filter);

  const handleStatus = async (id, status) => {
    await setQuoteStatus(id, status);
    setQuotes(prev => prev.map(q => q.id === id ? { ...q, status } : q));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between bg-white rounded-xl p-4 border border-gray-200">
        <h3 className="font-semibold text-gray-900">{t('Quotes')}</h3>
        <select className="border rounded-md px-3 py-2 text-sm" value={filter} onChange={e => setFilter(e.target.value)}>
          <option value="all">{t('All')}</option>
          <option value="submitted">{t('Submitted')}</option>
          <option value="approved">{t('Approved')}</option>
          <option value="rejected">{t('Rejected')}</option>
          <option value="accepted">{t('Accepted')}</option>
        </select>
      </div>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        <div className="w-full overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-4 py-2">{t('Request')}</th>
              <th className="text-left px-4 py-2">{t('Provider')}</th>
              <th className="text-left px-4 py-2">{t('Amount')}</th>
              <th className="text-left px-4 py-2">{t('Status')}</th>
              <th className="text-left px-4 py-2">{t('Actions')}</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td className="px-4 py-6" colSpan={5}>{t('Loading...')}</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td className="px-4 py-6" colSpan={5}>{t('No quotes found')}</td></tr>
            ) : filtered.map(q => (
              <tr key={q.id} className="border-t">
                <td className="px-4 py-2">{q.requestId}</td>
                <td className="px-4 py-2">{q.providerId}</td>
                <td className="px-4 py-2">${Number(q.amount || 0).toFixed(2)}</td>
                <td className="px-4 py-2">{q.status || 'submitted'}</td>
                <td className="px-4 py-2">
                  <select className="border rounded-md px-2 py-1" defaultValue={q.status} onChange={e => handleStatus(q.id, e.target.value)}>
                    <option value="submitted">{t('Submitted')}</option>
                    <option value="approved">{t('Approved')}</option>
                    <option value="rejected">{t('Rejected')}</option>
                    <option value="accepted">{t('Accepted')}</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
};

export default Quotes;