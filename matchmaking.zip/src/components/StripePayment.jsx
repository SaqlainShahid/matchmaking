import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { CardElement, useStripe, useElements, Elements } from '@stripe/react-stripe-js';

// Test publishable key provided by user
const stripePromise = loadStripe('pk_test_51SNd84L5LgrPfxcpEvZhbfXEWO0uMf1Qi1Y3R7Ib1ORCAG4JGWHl5HqdFu36maAxsj4LCYUoVm2JhmGR7jXInkXA00oOtHMN0t');

const CheckoutForm = ({ amount, providerName, requestTitle, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements) return;
    setIsProcessing(true);

    try {
      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: elements.getElement(CardElement),
        billing_details: {
          name: 'Test User',
        },
      });

      if (error) {
        onError(error.message);
        setIsProcessing(false);
        return;
      }

      // Attempt backend call (if available); otherwise fallback to test success
      try {
        const response = await fetch('/api/create-payment-intent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ amount: Math.round(Number(amount) * 100), paymentMethodId: paymentMethod.id }),
        });

        if (response.ok) {
          const { clientSecret } = await response.json();
          const { error: confirmError } = await stripe.confirmCardPayment(clientSecret);
          if (confirmError) {
            onError(confirmError.message);
          } else {
            onSuccess({ id: paymentMethod.id, amount, status: 'succeeded' });
          }
        } else {
          // No backend configured; simulate success in test mode
          onSuccess({ id: paymentMethod.id, amount, status: 'succeeded' });
        }
      } catch (e) {
        // Fallback to mock success in test mode
        onSuccess({ id: paymentMethod.id, amount, status: 'succeeded' });
      }
    } catch (err) {
      onError('Payment failed');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="border rounded-md p-4 bg-gray-50">
        <h4 className="text-sm font-semibold mb-2">Payment Summary</h4>
        <div className="text-sm text-gray-700 space-y-1">
          <div className="flex justify-between"><span>Provider</span><span className="font-medium">{providerName || '—'}</span></div>
          <div className="flex justify-between"><span>Request</span><span className="font-medium">{requestTitle || '—'}</span></div>
          <div className="flex justify-between"><span>Amount</span><span className="font-semibold">${(amount ?? 0).toLocaleString?.() || amount}</span></div>
        </div>
        <div className="mt-3 text-xs text-gray-500">Test Card: 4242 4242 4242 4242 • Any future expiry • Any CVC</div>
      </div>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="border rounded-md p-3">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#1f2937',
                  '::placeholder': { color: '#9ca3af' },
                },
              },
            }}
          />
        </div>
        <button type="submit" disabled={!stripe || isProcessing} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded w-full">
          {isProcessing ? 'Processing…' : `Pay $${amount}`}
        </button>
      </form>
    </div>
  );
};

const StripePayment = ({ amount, providerName, requestTitle, onSuccess, onError }) => {
  return (
    <Elements stripe={stripePromise}>
      <div>
        <CheckoutForm amount={amount} providerName={providerName} requestTitle={requestTitle} onSuccess={onSuccess} onError={onError} />
      </div>
    </Elements>
  );
};

export default StripePayment;